const xhr = new XMLHttpRequest(),
      url = "data.json";
  
  xhr.onreadystatechange = function() {
    if ( xhr.readyState === 4 && xhr.status === 200 ) {
      const menuItems = JSON.parse( xhr.responseText );
      // menuItems now holds the objects parsed from the JSON file. You will need to iterate over this and build a template html
    }
  };
  xhr.open( "GET", url, true );
  xhr.send();
  
  // Good place to put that function that will generate the template html
