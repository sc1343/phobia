const xhr = new XMLHttpRequest(),
    url = "data.json";
let output = "";

/*
function for json parse, and add element to listmenu
*/
xhr.addEventListener("load", function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
        const menuItems = JSON.parse(xhr.responseText);
        PhobiaList = JSON.parse(xhr.response);

        localStorage.setItem("Phobia list", JSON.stringify(PhobiaList));

        for (let phobia of PhobiaList) {
            output += templateTron(phobia);
        }
        document.getElementById('listMenu').innerHTML = output;
    }
});

xhr.open("GET", url, true);
xhr.send();

// save the selection
/* menu page */
function templateTron(phobia) {
    return `
        <div class = "id" onclick="saveSelection(${phobia.id})">
        <div class = 'background'>
		<div class = 'imageset'>
        <img src="assets/img/${phobia.pic}" alt='${phobia.pic}'> </img> </div>

        <h2>${phobia.name}</h2>
        <hr>
        </div>
        <div class = 'meaning'> Meaning: ${phobia.meaning} </div>
        <div class = 'population'> Affects: ~ ${phobia.million} million people </div>
     
		</div>


        `
}

/* direct to detail page using local storage */
function saveSelection(sel) {
    localStorage.setItem("selected", sel);
    window.open("detail.html", "_self");
}