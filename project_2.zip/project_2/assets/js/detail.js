let output = "";

//create list
const PhobiaList = JSON.parse(localStorage.getItem("Phobia list"));
const selectedID = localStorage.getItem('selected');

//storage the list
var select = localStorage.getItem("Phobia list");/* get the local storage id */

//default setting
if (select == null){
	  display();
	}
	
else {
for (let phobia of PhobiaList) {
	  if (selectedID == phobia.id){
        output += template(phobia);
        console.log("phobia id is " + phobia.id);
        addElement(output);
    }
    }
    }

/* add element to the page */
function addElement(data_input) {
    const newDiv = document.createElement("div");
    newDiv.id = "display";
    newDiv.insertAdjacentHTML('afterbegin', data_input);

    const currentDiv = document.getElementById("card_list");
    currentDiv.appendChild(newDiv);
};

/* print out the information form json file */
function template(phobia) {
    return `
       <div class = "phobia">
       
       <h2> <span id = 'num'> ${phobia.id} </span>  <span id = 'name'> ${phobia.name}  </span></h2>
       <h3 class = "mean">${phobia.meaning}</h3>
       <p><span>Population:  </span>${phobia.population}</p>
       <p><span>Affects: </span>~${phobia.million} million people</p>
       <p><span>Description: </span>${phobia.description}</p>
        <img class = "phobia-photo" src = "assets/img/${phobia.pic}">

       </div>`
}

//display the default
function display(){
 const xhr = new XMLHttpRequest(),
      url = "data.json";
  
  xhr.onreadystatechange = function() {
    if ( xhr.readyState === 4 && xhr.status === 200 ) {
      const PhobiaList = JSON.parse( xhr.responseText );
      for (let phobia of PhobiaList) {
            output += template(phobia);
      }
      document.getElementById('card_list').innerHTML = output;
    }
  };
  xhr.open( "GET", url, true );
  xhr.send();
    
    }

